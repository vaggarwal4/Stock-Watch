package com.vaibhavggarwal.stockwatch;
import java.io.Serializable;
/**
 * Created by Vaibhav on 3/5/2018.
 */
public class Stock implements Serializable {

    private String symbol;
    private String name;

    public Stock() {
    }

    public Stock(String sym, String nm) {


        symbol = sym;
        name= nm;
    }

    public String getSymbol(){return symbol;}

    public String getName(){return name;}


}
